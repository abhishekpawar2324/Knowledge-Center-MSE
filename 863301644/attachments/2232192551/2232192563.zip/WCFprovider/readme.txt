This is generic WCF service
You can start the WCF provider service with customize service name and port.

For example - You can start the service on port 8000 and name "my service"
WSGWProviderHost.exe "http://localhost:8000/my service/"

From browser you can see the wsdl definition using , which has 2 methods ( string append and numeric addition)

http://localhost:8000/my%20service/?wsdl

Load the WCF using WCF client in XPI
1) http://localhost:8000/my%20service/?wsdl
2) http://localhost:8000/my service/?wsdl


 
Good Luck