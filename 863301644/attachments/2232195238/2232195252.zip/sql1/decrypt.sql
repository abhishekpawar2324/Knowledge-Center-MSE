OPEN SYMMETRIC KEY skey DECRYPTION BY ASYMMETRIC KEY akey WITH PASSWORD = 'aaa123@'
set NoCount On
select CAST(DECRYPTBYKEY(Last_Name) as VARCHAR(100)) as Darpan from contacts1  for xml RAW,root('rows')
CLOSE SYMMETRIC KEY skey