cd /d %~dp0
sqlcmd -S localhost -d darpanDB -U sasa -P sasa -h -1 -i decrypt.sql -o output.xml