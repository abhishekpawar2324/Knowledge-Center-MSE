package com.magicsoftware.sdk;

import java.util.HashMap;

import com.magicsoftware.xpi.sdk.UserProperty;
import com.magicsoftware.xpi.sdk.trigger.TriggerGeneralParams;
import com.magicsoftware.xpi.sdk.trigger.polling.IPollingTrigger;

public class DynamicPollingTrigger1 implements IPollingTrigger {

	String path = "";
	private static final org.slf4j.Logger log = org.slf4j.LoggerFactory
			.getLogger(com.magicsoftware.sdk.DynamicPollingTrigger1.class);

	/*
	 * In order to use the slf4j facade and the logback infrastructure, you should
	 * configure logger and appender for this connector in the Runtime/java/classes
	 * folder
	 * 
	 * You should create a new logback configuration file, for example
	 * com.magicsoftware.sdk.DynamicPollingTrigger1.logback.xml :
	 * 
	 * ------------------------------ <?xml version="1.0" encoding="UTF-8"?>
	 * <included> <appender name="magicxpi-com.magicsoftware.sdk-appender"
	 * class="ch.qos.logback.core.rolling.RollingFileAppender">
	 * <file>${com.magicsoftware.ibolt.home}/logs/java/com.magicsoftware.sdk_${pid}.
	 * log</file> <encoder> <pattern>${xpi.internal.log.record.pattern}</pattern>
	 * </encoder> <rollingPolicy
	 * class="ch.qos.logback.core.rolling.SizeAndTimeBasedRollingPolicy">
	 * <fileNamePattern>${com.magicsoftware.ibolt.home}/logs/java/com.magicsoftware.
	 * sdk_${pid}_%d{yyyy-MM-dd}_%i.log</fileNamePattern>
	 * <maxFileSize>10MB</maxFileSize> <maxHistory>20</maxHistory>
	 * <totalSizeCap>300MB</totalSizeCap> </rollingPolicy> </appender> <logger
	 * name="com.magicsoftware.sdk" additivity="false" level="INFO"> <appender-ref
	 * ref="magicxpi-com.magicsoftware.sdk-appender" /> </logger> </included>
	 * ------------------------------
	 * 
	 * You should also reference your new
	 * com.magicsoftware.sdk.DynamicPollingTrigger1.logback.xml in the main
	 * logback.xml, as follows :
	 * 
	 * <include resource="com.magicsoftware.sdk.DynamicPollingTrigger1.logback.xml"
	 * />
	 * 
	 */

	private int counter = 0;

	//
	@Override
	public int getBufferLimit() {
		return 10;
	}

	@Override
	public int getKeepAliveInterval() {
		return 0;
	}

	@Override
	public int getPollingInterval() {
		return 10;
	}

	// Called first to load the trigger configurations and set the polling interval,
	// buffer size, etc.
	@Override
	public void load(TriggerGeneralParams loadGeneralParams) {
		log.info("Polling Trigger loaded");
		// Getting the configuration properties from the TriggerGeneralParams object
		UserProperty up = loadGeneralParams.getConfigurations().get("MyAlphaConfig");
		log.info("Trigger load. MyAlphaConfig = " + up.getValue().toString());
	}

	/*
	 * Invoke() will be called for each invocation cycle (based on the polling
	 * interval). The Boolean return value indicates to the server that results are
	 * available. If true is returned - An additional call to getPayload() will be
	 * performed in order to invoke the flow. If false is returned - It means that
	 * there are no results from this cycle. No flow will be invoked. The
	 * invokeGeneralParams contains a map of the UseForConfiguration properties that
	 * may change during the trigger's life cycle. For example, the startDate of
	 * Salesforce can be mapped to a Global variable that may change for each
	 * trigger invocation. In this method you should perform the trigger activity
	 * and store the result in a data structure accessible to the getPayload()
	 * method.
	 */
	@Override
	public boolean invoke(TriggerGeneralParams invokeGeneralParams) {
		log.debug("Invoke is called: Returning true");
		path = invokeGeneralParams.getEnviromentSettings().get("PROJECT_DIR");
		String runtimepath = System.getProperty("com.magicsoftware.ibolt.home");
		return true;
	}

	/*
	 * This method is responsible for the actual flow invocation. Each time the
	 * method ends, the flow will be invoked with the payload defined in the
	 * InvokeProperties object. The method returns a Boolean value that indicates if
	 * there are more results. If the method result is true, the server will send an
	 * invoke flow message to the space and will once again call the getPayload() in
	 * order to get the next payload. If the method result is false, the server will
	 * know that this was the last payload and will not call the method again.
	 * Instead, the server will send the invoke flow message to the space for this
	 * last call and call the InvokeDone() method to indicate that all messages
	 * resulting from this trigger invocation are in the space. The above mechanism
	 * allows the developer to split the trigger results into multiple trigger
	 * invocations and get back an indication when all results are safe in the
	 * space. We have a similar implementation for the Salesforce trigger when one
	 * result from Salesforce may be split into multiple flow invocations, each one
	 * with a subset of the data and in the end the SFtrigger.xml is updated with
	 * the lastCoveredData.
	 */
	@Override
	public boolean getPayload(HashMap<String, Object> InvokeProperties) {
		counter++;
		log.debug("getPayload called with counter=" + counter);
		InvokeProperties.put("inputvalue", path);

		if (counter == 3) { // This value was not defined as one of the TriggerIn arguments, so setting it
							// will result in an error and a call to onError().
			log.debug("Adding an unknown property. This will result in an error and onError() will be called");
			// InvokeProperties.put("Blobinputvalue", ("Blobinputvalue Blob_" +
			// path).getBytes());
//			 InvokeProperties.put("Blobinputvalue", ("Blobinputvalue Blob_" + this.counter).getBytes());
		}

		if (counter < 5)
			return true;
		return false;
	}

	/*
	 * Will be called once getPayload() returns false and the last invoke flow
	 * message was sent to the space. Once this method is called, we know that all
	 * of our messages that result from a single trigger invocation are in the
	 * space.
	 */
	@Override
	public void invokeDone() {
		log.debug("InvokeDone() is called to indicate the completion of a trigger cycle");
		counter = 0;
	}

	/*
	 * Will be called when getPayload() results in an error or the validation of the
	 * payload map has failed. In this scenario, the invoke flow of this specific
	 * payload will not be performed. The method returns either false - meaning that
	 * no further calls to getPayload() will be made and the server will call the
	 * invokeDone() done method or true - meaning that the error can be ignored.
	 */
	@Override
	public boolean onError(Exception ex) {
		log.debug("onError() is called!" + ex.getMessage());
		return true;
	}

	@Override
	public void unload() {
		// TODO Auto-generated method stub

	}
}
